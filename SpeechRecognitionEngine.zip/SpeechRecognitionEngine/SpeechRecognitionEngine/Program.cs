﻿using System;
using System.Threading;
using System.Speech.Recognition;
using System.IO;
using System.Speech.Recognition.SrgsGrammar;

namespace SpeechRecognitionEngine
{
	class Program
	{
		static void Main(string[] args)
		{
			SpeechRecognizer recognizer = new SpeechRecognizer();


			// Create a simple grammar that recognizes "red", "green", or "blue".
			/*Choices colors = new Choices();
			colors.Add(new string[] { "north fordham prep", "red", "green", "blue" });
			colors.Add(new SrgsRuleRef[] { SrgsRuleRef.Garbage });

			// Create a GrammarBuilder object and append the Choices object.

			GrammarBuilder gb = new GrammarBuilder(SrgsRuleRef.Garbage);
			gb.Append(SrgsRuleRef.Garbage);
            gb.Append(colors);

			Grammar g = new Grammar(gb);*/
			//recognizer.LoadGrammar(g);
			Grammar g = new Grammar("grammar.xml");
			recognizer.LoadGrammar(g);

			//recognizer.LoadGrammar(new DictationGrammar());

			recognizer.SpeechRecognized +=
			  new EventHandler<SpeechRecognizedEventArgs>(sre_SpeechRecognized);

            //TODO: enable the recognizer somehow

			Wait();
		}

		static void sre_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
		{
			string[] text = { e.Result.Text };
            File.WriteAllLines("speech.txt", text);
		}

		static void Wait()
		{
			while (true)
			{
				Thread.Sleep(100);
			}
		}
	}
}
