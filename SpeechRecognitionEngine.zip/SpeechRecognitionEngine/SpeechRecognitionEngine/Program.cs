﻿using System;
using System.Threading;
using System.Speech.Recognition;
using System.IO;

namespace SpeechRecognitionEngine
{
	class Program
	{
		static void Main(string[] args)
		{
			SpeechRecognizer recognizer = new SpeechRecognizer();

			/*
			// Create a simple grammar that recognizes "red", "green", or "blue".
			Choices colors = new Choices();
			colors.Add(new string[] { "red", "green", "blue" });

			// Create a GrammarBuilder object and append the Choices object.
			GrammarBuilder gb = new GrammarBuilder();
			gb.Append(colors);

			Grammar g = new Grammar(gb);
			recognizer.LoadGrammar(g);
			*/

			recognizer.LoadGrammar(new DictationGrammar());

			recognizer.SpeechRecognized +=
			  new EventHandler<SpeechRecognizedEventArgs>(sre_SpeechRecognized);

            //TODO: enable the recognizer somehow

			Wait();
		}

		static void sre_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
		{
			string[] text = { e.Result.Text };
            File.WriteAllLines("speech.txt", text);
		}

		static void Wait()
		{
			while (true)
			{
				Thread.Sleep(100);
			}
		}
	}
}
