import os, sys, nltk
from collections import defaultdict
from nltk.corpus import stopwords

def is_question(filtered):
	first_word = filtered[0].lower()
	questions = ["who", "what", "when", "where", "why", "how", "which"]
	if first_word in questions:
		return True
	return False

def find_subject(POS_dict):
	nouns = POS_dict.get('NN')
	if nouns is None: return None
	elif len(nouns) == 1: return nouns[0]
	else:
		return nouns[1]

def answer_question(POS_dict):	
	subject = find_subject(POS_dict)
	if subject == None:
		return "What are you talking about?"
	else:
		#match subject to voice line 
		return subject
	
def parse_speech():
	text = sys.argv[1]
	tokenized = nltk.word_tokenize(text)
	
	stop_words = set(stopwords.words('english')) 
	filtered = []
	
	#filter out words like "is", "the", etc.
	for word in tokenized:
		if word not in stop_words:
			filtered.append(word)
	
	POS_tagged = nltk.pos_tag(filtered) #tag parts of speech for each word
	
	POS_dict = {}.fromkeys(POS_tagged[k][1] for k in range(len(POS_tagged)))
	POS_dict = {k: [] for k in POS_dict}
	for (word, pos) in POS_tagged:
		POS_dict.get(pos).append(word)
	
	if is_question(filtered):
		return answer_question(POS_dict)
	else:
		return "That wasn't a question"

	
if __name__ == '__main__':
	print parse_speech()